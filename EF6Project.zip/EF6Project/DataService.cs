﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EF6Project
{
    public class DataService
    {
        public static DataService Init { get; } = new DataService(); //Singleton
        private DataService() { } //Singleton
        readonly DataModelContainer data = new DataModelContainer(); //DB Access
        public List<Teacher> GetTeachers() => data.People.OfType<Teacher>().ToList(); //Gets all teachers
        public void UpdateCourses(Teacher t, int i) //Updates the number (flag) of the teacher's courses
        {
            t.Course += i;
            data.SaveChanges();
        }
        public void UpdateGrade(Student s, int i) //Updates the student's grade
        {
            s.Grade = i;
            data.SaveChanges();
        }
        public Action<Teacher> UpdateStudentsByTeacherAction { get; set; } //Shows the students by teachers in the LV
        public void GetStudentsByTeacher(Teacher t) => UpdateStudentsByTeacherAction?.Invoke(t); //Shows the students by teachers in the LV
    }
}