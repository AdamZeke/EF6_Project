﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace EF6Project
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //DataMoc(); -- To add content to DB
        }

        private void DataMoc() //Run only once in order to add items to the database
        {
            using (var data = new DataModelContainer())
            {
                data.People.Add(new Teacher { Name = "Teacher1", Course = Courses.CSharp });
                data.People.Add(new Teacher { Name = "Teacher2", Course = Courses.PHP });
                data.People.Add(new Teacher { Name = "Teacher3", Course = Courses.GO });
                data.People.Add(new Student { Name = "Student1", Grade = 100 });
                data.People.Add(new Student { Name = "Student2", Grade = 85 });
                data.People.Add(new Student { Name = "Student3", Grade = 92 });
                data.People.Add(new Student { Name = "Student4", Grade = 90 });
                data.SaveChanges();
            }
            using (var data = new DataModelContainer())
            {
                List<Teacher> teachers = data.People.OfType<Teacher>().ToList();
                List<Student> students = data.People.OfType<Student>().ToList();
                teachers[0].Students.Add(students[0]);
                teachers[0].Students.Add(students[1]);
                teachers[1].Students.Add(students[2]);
                teachers[2].Students.Add(students[3]);
                data.SaveChanges();
            }
        }
    }
}
