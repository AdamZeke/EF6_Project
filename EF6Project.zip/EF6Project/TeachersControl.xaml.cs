﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace EF6Project
{
    public partial class TeachersControl : UserControl
    {
        public TeachersControl()
        {
            InitializeComponent();
            List<string> Courses = new List<string> { "C", "CSharp", "PHP", "Ruby", "GO", "Python", "JavaScript" }; //0,1,2,4,8,16,32
            comboTeachers.ItemsSource = Courses;
            lvTeachers.ItemsSource = DataService.Init.GetTeachers();
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            int selectedIndex = comboTeachers.SelectedIndex;
            var selectedTeach = lvTeachers.SelectedItem as Teacher;
            if (selectedTeach == null)
                MessageBox.Show("Please select a teacher first!");
            else
            {
                switch (selectedIndex)
                {
                    case 0:
                        DataService.Init.UpdateCourses(selectedTeach, 0);
                        MessageBox.Show("C was added!");
                        break;
                    case 1:
                        DataService.Init.UpdateCourses(selectedTeach, 1);
                        MessageBox.Show("C# was added!");
                        break;
                    case 2:
                        DataService.Init.UpdateCourses(selectedTeach, 2);
                        MessageBox.Show("PHP was added!");
                        break;
                    case 3:
                        DataService.Init.UpdateCourses(selectedTeach, 4);
                        MessageBox.Show("Ruby was added!");
                        break;
                    case 4:
                        DataService.Init.UpdateCourses(selectedTeach, 8);
                        MessageBox.Show("GO was added!");
                        break;
                    case 5:
                        DataService.Init.UpdateCourses(selectedTeach, 16);
                        MessageBox.Show("Python was added!");
                        break;
                    case 6:
                        DataService.Init.UpdateCourses(selectedTeach, 32);
                        MessageBox.Show("JavaScript was added!");
                        break;
                    default:
                        MessageBox.Show("No course was added!");
                        break;
                }
            }
        }

        private void lvTeachers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var teacher = (Teacher)lvTeachers.SelectedItem;
            DataService.Init.GetStudentsByTeacher(teacher);
        }
    }
}
