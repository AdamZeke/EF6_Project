﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace EF6Project
{
    public partial class StudentsControl : UserControl
    {
        public StudentsControl()
        {
            InitializeComponent();
            DataService.Init.UpdateStudentsByTeacherAction = UpdateStudentsByTeacher; 
        }
        private void UpdateStudentsByTeacher(Teacher t) => lvStudents.ItemsSource = t.Students.ToList(); //invokes method to show students by teachers

        private void btn_Update_Click(object sender, System.Windows.RoutedEventArgs e) //Updates the selected student's grade
        {
            int grade;
            var student = lvStudents.SelectedItem as Student;
            var rawGrade = txtbox_Grade.Text;
            if (!int.TryParse(rawGrade, out grade))
            {
                MessageBox.Show("Invalid grade entered.");
                return;
            }
            if (grade > 100 || grade < 0 || student == null)
            {
                MessageBox.Show("Invalid grade entered or no student chosen.");
                return;
            }
            DataService.Init.UpdateGrade(student, grade);
            MessageBox.Show("Grade updated!");
        }
    }
}
