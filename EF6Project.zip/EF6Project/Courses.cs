
namespace EF6Project
{
    using System;
    [Flags]
    public enum Courses : int
    {
        C = 0,
        CSharp = 1,
        PHP = 2,
        Ruby = 4,
        GO = 8,
        Python = 16,
        JavaScript = 32,
    }
}
